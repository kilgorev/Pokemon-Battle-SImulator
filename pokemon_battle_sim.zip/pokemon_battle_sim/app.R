library(shiny)
library(ggplot2)
library(bslib)
library(readr)
library(tidyverse)
library(tibble)
library(ggpubr)
library(dplyr)
library(tidyr)
library(rvest)

ui <- page_navbar(
  title = "Pokemon Battle Simulator",
  selected = "Battle!",
  collapsible = TRUE,
  theme = bslib::bs_theme(),
  nav_panel(
    theme = bslib::bs_theme(),
    title = "Battle!",
    tags$div(
      class = "container-fluid",  
      tags$div(
        class = "row",  
        tags$div(
          class = "col-md-6",
          card(
            full_screen = TRUE,
            card_body(
              tags$div( class = "row",
                        card(  class = "col-md-6",
                               selectInput(
                                 inputId = "pokemon1",
                                 label = "Select Pokemon",
                                 choices = pokemon$name
                               ),
                               imageOutput(outputId = "pokeImage1",
                                           width = "100px", height = "100px"),
                        ),
                        card( class = "col-md-6",
                              uiOutput(outputId = "statsBar1",
                                       inline = TRUE
                              )  # Add stats bar next to Pokemon 1
                        )
              )
            )
          )
        ),
        tags$div(
          class = "col-md-6",  
          card(
            full_screen = TRUE,
            card_body(
              tags$div( class = "row",
                        card(  class = "col-md-6",
                               selectInput(
                                 inputId = "pokemon2",
                                 label = "Select Pokemon",
                                 choices = pokemon$name
                               ),
                               imageOutput(outputId = "pokeImage2",
                                           width = "100px", height = "100px"),
                        ),
                        card( class = "col-md-6",
                              uiOutput(outputId = "statsBar2",
                                       inline = TRUE) 
                        )
              )
            )
          )
        )
      ),
      tags$div(
        class = "row justify-content-center",  
        tags$div(
          class = "col-md-6",
          card(
            full_screen = TRUE,
            card_body(
              div(
                class = "text-center", 
                textOutput(outputId = "winnerOutput"),
                div(
                  imageOutput(
                    outputId = "winnerOutputPic",
                    width = "200px",
                    height = "200px",
                    inline = TRUE
                  )
                )
              ),
              actionButton(inputId = "battleButton", label = "BATTLE!")
            )
          )
        )
      )
    )
  )
)



server <- function(input, output) {
  
  output$pokeImage1 <- renderImage({
    list(src = paste0("pokemon_images/all/", tolower(input$pokemon1), ".png"))
  }, deleteFile = FALSE)
  
  output$pokeImage2 <- renderImage({
    list(src = paste0("pokemon_images/all/", tolower(input$pokemon2), ".png"))
  }, deleteFile = FALSE)
  

  
  output$statsBar1 <- renderUI({
   
    stats_data <- stats(pokemon = input$pokemon1)
    
    stats_table <- tableOutput("statsTable1")
    div(
      class = "text-center",  
      tags$h4(paste(input$pokemon1, " Stats")),   
      stats_table       
    )
    
  })
  
  
  output$statsTable1 <- renderTable({
    stats_data <- stats(pokemon = input$pokemon1)
    stats_data
  }, rownames = FALSE)
  
  
  output$statsBar2 <- renderUI({
    stats_data <- stats(pokemon = input$pokemon2)
    

    stats_table <- tableOutput("statsTable2")
    div(
      class = "text-center", inline = TRUE, 
      tags$h4(paste(input$pokemon2, " Stats")),   
      stats_table
    )

    
  })
  
  
  output$statsTable2 <- renderTable({
    stats_data <- stats(pokemon = input$pokemon2)
    stats_data
  }, rownames = FALSE)
  
  output$pokeImage1 <- renderImage({
    list(src = paste0("pokemon_images/all/", tolower(input$pokemon1), ".png"))
  }, deleteFile = FALSE)
  
  output$pokeImage2 <- renderImage({
    list(src = paste0("pokemon_images/all/", tolower(input$pokemon2), ".png"))
  }, deleteFile = FALSE)
  
  winnerOutput <- eventReactive(input$battleButton, {
    battle(pokemon1 = input$pokemon1, pokemon2 = input$pokemon2)
  })
  
  output$winnerOutput <- renderText({
    winnerOutput()
  })
  
  winnerOutputPic <- eventReactive(input$battleButton, {
    battlePic(pokemon1 = input$pokemon1, pokemon2 = input$pokemon2)
  })
  
  output$winnerOutputPic <- renderImage({
    if(input$battleButton > 0){
      list(src = winnerOutputPic(),
           width = "200px",
           height = "200px")
    } else {
      list(src = "pokemon_images/all/pokeball.png",
           width = "200px",
           height = "200px")
    }
  }, deleteFile = FALSE)
  
}


shinyApp(ui, server)
